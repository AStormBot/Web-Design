function find() {
    const edit = `<h1>Welcome to Your hell</h1> <p>I Don't want talk about my self!</p>\
<p>Just I want Talk About your crazy mode</p>
<p>I want use it, and ...</p>`;
    const find = document.getElementById('find');
    find.innerHTML = edit;
}
function killer() {
    const die = document.getElementById('secret-Job')
    die.innerHTML = `<h1>Hello New teammate!</h1>\
 <p>You are here for help us. you can do <br><span id="you-love-your-job">!@#$%^@#$%^%#$</span> here. </p>\
<p>I don't like this job, someone told me "You have to do it". but I don't know who was that, I didn't see him.</p>\
<p>Just I heard him</p>`;
}
function never() {
    const ever = document.getElementById('never')
    ever.innerHTML = `<p>this is my power!</p> <p>So now do what I say to you</p>\
<p>Why?</p><p>Why not. this is command.</p>\
<p>if I don't do it?</p><p>i will hug you</p>`
}
// I don't need to give perm to use it
// Just Use.
// you can't not stop me
// I'm Coming!
// Just i want Have little Fun
// With your ...