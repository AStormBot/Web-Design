const target = document.getElementById('news-media')
function site() {
    document.getElementById('news-media').innerHTML = "<ul><li><img src='./Media/background.jpg' alt='Site Image'></li><li><h1>Web Opened</h1>" +
        "<p>After 1 million years, we created big update for site!</p>" +
        "<p>So Now! Let's play or learn!</p>" +
        "<p></p></li></ul>"
}
function never() {

}